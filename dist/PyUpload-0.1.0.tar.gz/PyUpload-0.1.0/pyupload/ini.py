import ConfigParser

config = ConfigParser.ConfigParser()
config.read('config.ini')
